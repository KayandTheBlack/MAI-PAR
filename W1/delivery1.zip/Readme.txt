All the information to run the planner is available in the
last section of the pdf. You will need to download and compile
Metric-FF, or a similar solver for running it.

Student name: Victor Gimenez Abalos
